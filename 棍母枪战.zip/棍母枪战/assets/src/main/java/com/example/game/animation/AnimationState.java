package com.example.game.animation;

import com.jme3.anim.AnimComposer;
import com.jme3.anim.tween.action.Action;
import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.scene.Spatial;

/**
 * 骨骼动画混合：
 * - lower 通道：行走/奔跑/待机
 * - upper 通道：射击/换弹/技能
 * - 使用 AnimComposer 的多通道能力
 */
public class AnimationState extends BaseAppState {

    private AnimComposer composer;

    public void bind(Spatial playerModel) {
        composer = playerModel.getControl(AnimComposer.class);
        if (composer == null) return;

        // 上下半身分通道
        composer.makeLayer("lower", false);
        composer.makeLayer("upper", false);

        composer.setCurrentAction("Idle", "lower");
        composer.setCurrentAction("AimIdle", "upper");
    }

    public void setLocomotion(String anim) {
        if (composer != null) composer.setCurrentAction(anim, "lower");
    }

    public void setUpperAction(String anim) {
        if (composer != null) composer.setCurrentAction(anim, "upper");
    }

    @Override protected void initialize(Application app) {}
    @Override protected void cleanup(Application app) {}
    @Override protected void onEnable() {}
    @Override protected void onDisable() {}
}