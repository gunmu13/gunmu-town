package com.example.game.net;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.network.Network;
import com.jme3.network.Server;
import java.io.IOException;

/**
 * 服务端模式：java -jar game.jar --server
 * 客户端模式：默认
 */
public class NetworkState extends BaseAppState {

    private Server server;

    @Override
    protected void initialize(Application app) {
        boolean isServer = app.getContext().getSettings()
                .getBoolean("Server"); // 可通过启动参数注入
        if (isServer) {
            try {
                server = Network.createServer(6143);
                server.start();
            } catch (IOException e) {
                throw new RuntimeException("无法启动服务器", e);
            }
        }
    }

    @Override protected void cleanup(Application app) {
        if (server != null) server.close();
    }
    @Override protected void onEnable() {}
    @Override protected void onDisable() {}
}