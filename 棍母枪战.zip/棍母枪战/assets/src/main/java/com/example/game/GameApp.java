package com.example.game;

import com.example.game.audio.AudioState;
import com.example.game.combat.CombatState;
import com.example.game.core.GameLoopState;
import com.example.game.ecs.EntityDataState;
import com.example.game.net.NetworkState;
import com.example.game.physics.PhysicsState;
import com.example.game.terrain.TerrainState;
import com.jme3.app.SimpleApplication;
import com.jme3.asset.plugins.FileLocator;
import com.jme3.system.AppSettings;
import java.io.File;

public class GameApp extends SimpleApplication {

    public static void main(String[] args) {
        GameApp app = new GameApp();
        AppSettings s = new AppSettings(true);
        s.setTitle("High Quality Java Game");
        s.setResolution(1920, 1080);
        s.setVSync(true);
        s.setFrameRate(144);
        app.setSettings(s);
        app.setShowSettings(false);
        app.start();
    }

    @Override
    public void simpleInitApp() {
        flyCam.setMoveSpeed(40f);

        // 外部 assets 目录：发布时与 game.jar 同级
        File assetsDir = new File(System.getProperty("user.dir"), "assets");
        if (assetsDir.isDirectory()) {
            assetManager.registerLocator(assetsDir.getAbsolutePath(), FileLocator.class);
        }

        // AppState 按依赖顺序装配
        stateManager.attach(new EntityDataState());   // ECS 世界
        stateManager.attach(new PhysicsState());      // Minie 物理
        stateManager.attach(new TerrainState());      // 无限地形
        stateManager.attach(new CombatState());       // 战斗与弹道
        stateManager.attach(new AudioState());        // 3D 音频
        stateManager.attach(new NetworkState());      // SpiderMonkey
        stateManager.attach(new GameLoopState());     // 固定时间步长
    }
}