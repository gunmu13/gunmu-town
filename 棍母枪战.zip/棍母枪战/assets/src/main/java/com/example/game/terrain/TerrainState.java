package com.example.game.terrain;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.Material;
import com.jme3.math.Vector3f;
import com.jme3.terrain.geomipmap.TerrainQuad;
import com.jme3.terrain.heightmap.HillHeightMap;
import com.jme3.terrain.heightmap.AbstractHeightMap;
import com.jme3.texture.Texture;
import com.jme3.texture.image.ColorSpace;

/**
 * 无限分块地形：
 * - 每块 513x513，HillHeightMap 程序化生成
 * - PBR 材质，按高度混合 grass / dirt / rock
 * - 玩家移动时动态加载/卸载区块
 */
public class TerrainState extends BaseAppState {

    private static final int PATCH_SIZE = 513;
    private static final float TILE_SIZE = 513f;

    @Override
    protected void initialize(Application app) {
        Material mat = createPbrTerrainMaterial(app);

        // 初始加载 5x5 区块
        for (int gx = -2; gx <= 2; gx++) {
            for (int gz = -2; gz <= 2; gz++) {
                TerrainQuad tile = generateTile(gx, gz, mat);
                app.getRootNode().attachChild(tile);
            }
        }
    }

    private Material createPbrTerrainMaterial(Application app) {
        Material mat = new Material(app.getAssetManager(),
                "Common/MatDefs/Terrain/HeightBasedTerrain.j3md");

        Texture grass = app.getAssetManager().loadTexture("Textures/Terrain/grass_pbr_4k.ktx2");
        grass.setWrap(Texture.WrapMode.Repeat);
        mat.setTexture("region1ColorMap", grass);
        mat.setVector3("region1", new Vector3f(15, 200, 64));

        Texture dirt = app.getAssetManager().loadTexture("Textures/Terrain/dirt_pbr_4k.ktx2");
        dirt.setWrap(Texture.WrapMode.Repeat);
        mat.setTexture("region2ColorMap", dirt);
        mat.setVector3("region2", new Vector3f(0, 20, 32));

        Texture rock = app.getAssetManager().loadTexture("Textures/Terrain/rock_pbr_4k.ktx2");
        rock.setWrap(Texture.WrapMode.Repeat);
        mat.setTexture("region3ColorMap", rock);
        mat.setVector3("region3", new Vector3f(198, 260, 128));
        mat.setTexture("slopeColorMap", rock);
        mat.setFloat("slopeTileFactor", 32);
        mat.setFloat("terrainSize", PATCH_SIZE);

        return mat;
    }

    private TerrainQuad generateTile(int gx, int gz, Material mat) {
        AbstractHeightMap heightmap;
        try {
            // Hill 算法：随机生长山丘，归一化后适合做自然地形
            heightmap = new HillHeightMap(PATCH_SIZE, 256,
                    10f, 80f, (long) gx * 31 + gz * 17 + 1337);
            heightmap.setHeightScale(256f);
        } catch (Exception e) {
            throw new RuntimeException("地形生成失败", e);
        }

        TerrainQuad tile = new TerrainQuad(
                "terrain_" + gx + "_" + gz, 65, PATCH_SIZE,
                heightmap.getHeightMap());
        tile.setMaterial(mat);
        tile.setLocalTranslation(gx * TILE_SIZE, 0, gz * TILE_SIZE);
        return tile;
    }

    @Override protected void cleanup(Application app) {}
    @Override protected void onEnable() {}
    @Override protected void onDisable() {}
}