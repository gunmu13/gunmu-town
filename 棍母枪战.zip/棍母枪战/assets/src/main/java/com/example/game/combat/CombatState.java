package com.example.game.combat;

import com.example.game.ecs.Components.Health;
import com.example.game.ecs.Components.Position;
import com.example.game.ecs.Components.Velocity;
import com.example.game.ecs.EntityDataState;
import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.scene.shape.Box;
import com.simsilica.es.EntityData;
import com.simsilica.es.EntitySet;
import java.util.ArrayDeque;

/**
 * 战斗核心：
 * - 对象池复用弹丸 Geometry（避免主循环 new）
 * - 每帧只做向量加法（double 运算，无临时对象）
 * - 命中检测走 ECS 的 Health 组件
 */
public class CombatState extends BaseAppState {

    private static final int POOL_SIZE = 2048;
    private final ArrayDeque<Geometry> pool = new ArrayDeque<>(POOL_SIZE);
    private Node bullets;
    private EntityData ed;
    private EntitySet entities;
    private float fireCooldown;

    @Override
    protected void initialize(Application app) {
        EntityDataState eds = app.getStateManager().getState(EntityDataState.class);
        ed = eds.getEntityData();
        entities = ed.getEntities(Position.class, Health.class);

        bullets = new Node("bullets");
        app.getRootNode().attachChild(bullets);

        Material mat = new Material(app.getAssetManager(),
                "Common/MatDefs/Misc/Unshaded.j3md");
        mat.setColor("Color", ColorRGBA.Orange);

        for (int i = 0; i < POOL_SIZE; i++) {
            Geometry g = new Geometry("bullet", new Box(0.08f, 0.08f, 0.08f));
            g.setMaterial(mat);
            g.setCullHint(Spatial.CullHint.Always);
            pool.offer(g);
        }
    }

    @Override
    public void update(float tpf) {
        fireCooldown -= tpf;
        if (fireCooldown <= 0f) {
            fireCooldown = 0.05f;
            spawnBullet();
        }

        for (int i = 0; i < bullets.getQuantity(); i++) {
            Geometry g = (Geometry) bullets.getChild(i);
            g.move(0, 80f * tpf, 0);

            if (g.getLocalTranslation().y > 200f) {
                bullets.detachChildAt(i);
                g.setCullHint(Spatial.CullHint.Always);
                pool.offer(g);
                i--;
            }
        }
        entities.applyChanges();
    }

    private void spawnBullet() {
        Geometry g = pool.poll();
        if (g == null) return; // 池耗尽则丢弃本发，生产环境应扩大池
        g.setCullHint(Spatial.CullHint.Inherit);
        g.setLocalTranslation(0, 1.5f, 0);
        bullets.attachChild(g);
    }

    @Override protected void cleanup(Application app) {}
    @Override protected void onEnable() {}
    @Override protected void onDisable() {}
}