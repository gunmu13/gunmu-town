package com.example.game.audio;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.jme3.audio.AudioNode;
import com.jme3.audio.Environment;
import com.jme3.math.Vector3f;

public class AudioState extends BaseAppState {

    private AudioNode gunshot;
    private AudioNode ambience;

    @Override
    protected void initialize(Application app) {
        // 环境混响：开阔战场
        app.getAudioRenderer().setEnvironment(
                Environment.Cavern); // 也可用 Garage, Dungeon 等预设

        gunshot = new AudioNode(app.getAssetManager(),
                "Sounds/sfx_gunshot_48khz.flac", false);
        gunshot.setPositional(true);
        gunshot.setLocalTranslation(Vector3f.ZERO);
        gunshot.setReverbEnabled(true);
        app.getRootNode().attachChild(gunshot);

        ambience = new AudioNode(app.getAssetManager(),
                "Sounds/bgm_battle_lossless.flac", true);
        ambience.setLooping(true);
        ambience.setVolume(0.6f);
        ambience.play();
    }

    public void playGunshot(Vector3f pos) {
        gunshot.setLocalTranslation(pos);
        gunshot.playInstance();
    }

    @Override protected void cleanup(Application app) {}
    @Override protected void onEnable() {}
    @Override protected void onDisable() {}
}