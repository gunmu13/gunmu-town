package com.example.game.ecs;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;
import com.simsilica.es.EntityData;
import com.simsilica.es.base.DefaultEntityData;

public class EntityDataState extends BaseAppState {

    private EntityData entityData;

    @Override protected void initialize(Application app) {
        entityData = new DefaultEntityData();
    }

    public EntityData getEntityData() { return entityData; }

    @Override protected void cleanup(Application app) {}
    @Override protected void onEnable() {}
    @Override protected void onDisable() {}
}