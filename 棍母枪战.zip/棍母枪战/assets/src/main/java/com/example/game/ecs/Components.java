package com.example.game.ecs;

import com.simsilica.es.EntityComponent;

public final class Components {

    public record Position(double x, double y, double z) implements EntityComponent {}
    public record Velocity(double x, double y, double z) implements EntityComponent {}
    public record Health(int current, int max) implements EntityComponent {}
    public record Damage(int amount) implements EntityComponent {}
    public record Visual(String modelPath) implements EntityComponent {}
    public record Collision(float radius) implements EntityComponent {}
    public record NetworkId(long id) implements EntityComponent {}

    private Components() {}
}