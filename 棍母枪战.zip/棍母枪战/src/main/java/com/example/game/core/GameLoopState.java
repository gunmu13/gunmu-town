package com.example.game.core;

import com.jme3.app.Application;
import com.jme3.app.state.BaseAppState;

public class GameLoopState extends BaseAppState {

    private static final double STEP = 1.0 / 60.0;
    private double accumulator;

    @Override public void update(float tpf) {
        accumulator += tpf;
        while (accumulator >= STEP) {
            fixedUpdate();
            accumulator -= STEP;
        }
    }

    private void fixedUpdate() {
        // 物理、AI、弹道等对时间敏感的逻辑放这里
    }

    @Override protected void initialize(Application app) {}
    @Override protected void cleanup(Application app) {}
    @Override protected void onEnable() {}
    @Override protected void onDisable() {}
}