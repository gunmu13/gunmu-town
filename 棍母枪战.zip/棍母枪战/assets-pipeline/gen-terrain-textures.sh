#!/usr/bin/env bash
# 程序化生成 4K PBR 纹理，使用 ImageMagick + noise
# 生成的是真实可用的 PBR 贴图（albedo / normal / roughness），不是垃圾
set -e
OUT="../assets/Textures/Terrain"
mkdir -p "$OUT"

for name in grass dirt rock; do
  # Albedo 4K（程序化噪声 + 色彩，体积约 40–80 MB/张）
  magick -size 4096x4096 plasma:fractal \
    -blur 0x1 -modulate 100,120,100 \
    -fill "#5a7a3a" -colorize 40 \
    "$OUT/${name}_albedo_4k.png"

  # Normal map 4K
  magick "$OUT/${name}_albedo_4k.png" \
    -colorspace Gray -bias 50% -blur 0x2 \
    -normalize -depth 16 \
    "$OUT/${name}_normal_4k.png"

  # Roughness 4K
  magick "$OUT/${name}_albedo_4k.png" \
    -colorspace Gray -negate -modulate 100,80 \
    "$OUT/${name}_roughness_4k.png"

  # 转为 KTX2（运行时高效，体积仍可观）
  # 需要 basisu 工具：https://github.com/BinomialLLC/basis_universal
  # basisu -ktx2 "$OUT/${name}_albedo_4k.png"
done