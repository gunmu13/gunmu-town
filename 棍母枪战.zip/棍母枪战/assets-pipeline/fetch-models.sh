#!/usr/bin/env bash
# 拉取高质量开源 GLB 模型（Kenney / Quaternius 等 CC0 资源）
set -e
OUT="../assets/Models"
mkdir -p "$OUT"

# 示例：Quaternius 的 Ultimate Modular Character Pack（CC0）
# 实际使用时替换为你的资源 URL
# curl -L -o "$OUT/character_pack.zip" https://example.com/character_pack.zip
# unzip -o "$OUT/character_pack.zip" -d "$OUT/"