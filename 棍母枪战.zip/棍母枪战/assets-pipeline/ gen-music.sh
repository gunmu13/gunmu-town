#!/usr/bin/env bash
# 程序化生成无损 FLAC BGM（使用 SoX 合成环境音）
set -e
OUT="../assets/Sounds"
mkdir -p "$OUT"

# 生成 8 分钟无损战场环境音（约 80–150 MB FLAC）
sox -n -r 48000 -c 2 -b 16 "$OUT/bgm_battle.wav" \
  synth 480 brownnoise vol 0.3 \
  : synth 480 sine 55 vol 0.15 \
  : synth 480 sine 110 vol 0.08 \
  fade 0 480 30

flac -8 "$OUT/bgm_battle.wav" -o "$OUT/bgm_battle_lossless.flac"
rm "$OUT/bgm_battle.wav"